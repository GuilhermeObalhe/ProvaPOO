﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Imaginario
{
    internal class NumComplexo
    {
        // Atributos
        private double Re;
        private double Im;


        // Métodos e construtores
        public NumComplexo() // Construtor default
        {
            Re = 0;
            Im = 0;
        }

        public NumComplexo(double _Re, double _Im) // Construtor com parâmetros
        {
            Re = _Re;
            Im = _Im;
        }
        
        public NumComplexo soma(NumComplexo n1)
        {
            return new NumComplexo(Re + n1.Re, Im + n1.Im);
        }

        public NumComplexo vezes(NumComplexo n1)
        {
            double real = (Re * n1.Re) - (Im * n1.Im);
            double imaginario = (Re * n1.Im) + (Im * n1.Re);
            return new NumComplexo(real, imaginario);
        }

        public double Modulo()
        {
            return Math.Sqrt((Re * Re) + (Im * Im));
        }

        public double Argumento()
        {
            return Math.Atan2(Im, Re);
        }

        public void ImprimeFormaPolar()
        {
            double modulo = Modulo();
            double argumento = Argumento();
            Console.WriteLine($"Forma polar: {modulo} * (cos({argumento}) + i * sin({argumento}))");
        }

        // Getters e Setters
        public double Re1 { get => Re; set => Re = value; }
        public double Im1 { get => Im; set => Im = value; }
    }
}
