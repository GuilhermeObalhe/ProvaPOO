﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um nome: ");
            string Nome = Console.ReadLine();
            NomeProprio autor = new NomeProprio(Nome);

            autor.ImprimeNomePaper();
            Console.ReadLine();
        }
    }
}