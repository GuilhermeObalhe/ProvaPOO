﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao01
{
    internal class NomeProprio
    {
        // Atributos
        private string nome_completo;
        private string nome_paper;

        // Construtores e métodos
        public NomeProprio() // Construtor default
        {

        }
        public NomeProprio(string _nome_completo) // Construtor com parâmetros
        {
            nome_completo = _nome_completo;
            nome_paper = GeraNome();
        }

        // Método que gera o nome no formato paper
        public string GeraNome()
        {
            string[] Nome = nome_completo.Split(' ');

            // Caso o nome seja único, então retorna esse nome
            if (Nome.Length == 1)
            {
                return Nome[0];
            }

            string Sobrenome = Nome[Nome.Length - 1];
            string PrimeiroNome = Nome[0];
            string NomeMeio = "";

            for (int i = 1; i < Nome.Length - 1; i++) // Itera sobre os nomes do meio
            {
                if (!string.IsNullOrWhiteSpace(Nome[i])) // Ignora nomes vazios ou espaços extras
                {
                    NomeMeio += Nome[i][0] + ". "; // Adiciona a inicial do nome do meio
                }
            }

            return $"{Sobrenome}, {PrimeiroNome} {NomeMeio.Trim()}";
        }

        // Método para imprimir o nome
        public void ImprimeNomePaper()
        {
            Console.WriteLine(nome_paper);
        }

        // Getters e Setters
        public string Nome_completo { get => nome_completo; set => nome_completo = value; }
        public string Nome_paper { get => nome_paper; set => nome_paper = value; }

    }
}
